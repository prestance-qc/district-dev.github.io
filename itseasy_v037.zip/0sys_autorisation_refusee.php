<?php
/*@mail($email_webmaster, $nom_du_projet . " : tentative d'intrusion",stripslashes(
"Bonjour,\n
Une tentative d'intrusion a �t� d�cel�e sur votre site $url_du_site.\n
Utilisateur :" . $_SERVER['REMOTE_ADDR'] . " @ " . date(H . ":" . i . ":" . s) . " le " . date(d ."/" . m . "/" . "Y") . $_SERVER['REMOTE_HOST'] .
"\n--\n
Merci d'utiliser $nom_du_projet :o)\n
N'h�sitez pas � v�rifier si vous disposez bien de la derni�re version sur <a href=\"$nom_du_projet\">$url_du_projet</a>."));*/

// Si tentative de hack on d�truit toute trace de sessions et on lui dit qu'on est pas content.
session_unset();
session_destroy();
require("./header.php");
?>

<h1>Acc�s refus� :o(</h1>
<p>Vous n'�tes pas autoris� � acc�der � cette page.</p>

<hr />

<h1>Mise en garde</h1>

<p>Attention, cette tentative de connexion �chou�e viens d'�tre notifi�e � l'Administrateur de ce site.</p>

<?php
require("./footer.php");
?>