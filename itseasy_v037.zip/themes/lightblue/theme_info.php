<?php
$nom_du_theme = "Light Blue";
$auteur_du_theme = "Vanquish";
$url_auteur_du_theme = "http://www.en1heure.com/";
$nom_styles_css = "styles100";
//$nom_styles_css = "styles";
?>
