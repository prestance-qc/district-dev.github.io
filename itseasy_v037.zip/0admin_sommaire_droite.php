<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");
require_once("./0admin_rss_itseasy.php");
?>

<?php
// Si la page actuelle est la d�connexion de l'amdin... on ne met pas de lien pour retourner � l'admin
if(basename($_SERVER['PHP_SELF']) != "0admin_deconnexion.php") echo '<p><a href="./0admin_index.php?sid='.session_id().'">Accueil administration</a></p>' ?>
<!-- FIN ARTICLE -->
<!-- DEBUT SOMMAIRE DROITE -->
</div>
</div>
<div class="droite">

<div class="block_sommaire_droite">
<h1>M�t�o</h1>
<p><img src="http://perso0.free.fr/cgi-bin/meteo.pl?dep=<?php echo $numero_de_departement ?>" alt="M�t�o de votre d�partement" />
</div>

<div class="block_sommaire_droite">

<?php
// Si c'est faisable on affiche les informations en cours sur Itseasy (news, releases, etc...)
@rss();
?>
</div>

</div>
<!-- FIN SOMMAIRE DROITE -->
