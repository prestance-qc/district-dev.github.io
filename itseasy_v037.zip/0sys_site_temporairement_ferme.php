<div class="article_locked">
<div class="contenu_article">
<h1><?php echo $nom_du_site ?> est temporairement ferm�</h1>
<p>Bonjour � toutes et � tous,
<br />
<?php echo $nom_du_site ?> est ferm� depuis le <?php echo $date_fermeture . " � " . $heure_fermeture ?> pour cause de maintenance, merci 
de repasser plus tard.
<br />
Veuillez nous excuser pour la g�ne occasionn�e.</p>
</div>
</div>

<?php
require("./footer.php");
?>