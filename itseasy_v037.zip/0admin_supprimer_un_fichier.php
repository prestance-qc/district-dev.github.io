<?php
$titre_page = "Supprimer un fichier";
require("./0admin_header.php");
?>

<h1>Suppression de <?php echo $_GET['file'] ?></h1>
<?php
if(!file_exists($_GET['file'])) {
echo "<h1>Erreur : fichier introuvable</h1>
<p>Le fichier � supprimer est introuvable.</p>";
require("./0admin_footer.php");
exit();
}
// Si c'est un fichier syst�me on le dit � l'utilisateur pour qu'il ne fasse pas de sottise
if(ereg("0admin_",$_GET['file']) || ereg("0sys_",$_GET['file']) || $_GET['file'] == ".htaccess") echo "
<div class=\"marge_h2\">
<h2>ATTENTION</h2>
<p><strong>$_GET[file] est un fichier syst�me n�cessaire � $nom_du_projet, le supprimer peut rendre votre site inutilisable.</strong></p>
</div>

<hr />";
?>

<div class="marge_h2">
<h2>Confirmation</h2>
<p>Voulez vous r�ellement supprimer <strong><?php echo $_GET['file'] ?></strong> ?
<form method="POST" action="./0admin_supprimer_un_fichier_engine.php?sid=<?php echo session_id() ?>&file=<?php echo $_GET['file'] ?>">
<input type="submit" name="confirmation" value="Confirmer" /></p>
</form>
</div>

<?php
require("./0admin_footer.php");
?>