<?php
$titre_page = "Renommer un fichier";
require("./0admin_header.php");

if(file_exists($_GET['file'])) {
rename($_GET['file'], $_POST['nom_du_fichier']);
echo "<h1>Op�ration termin�e</h1>
<p>Le fichier <strong>$_GET[file]</strong> a  bien �t� renomm� <strong>$_POST[nom_du_fichier]</strong></p>";}
else echo "<h1>Erreur : fichier invalide</h1>
<p>Vous devez sp�cifier un fichier valide.</p>";
require("./0admin_footer.php");
?>