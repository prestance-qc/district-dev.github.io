<?php
$titre_page = "Gestion des erreurs 404";
require("./0admin_header.php");

if(file_exists("./.htaccess")) {
$handle = fopen("./.htaccess","r");
$configuration = fread($handle,filesize("./.htaccess"));
echo '<h1>Configuration de votre fichier .htaccess</h1>
<p>Voici le contenu de votre fichier .htaccess. Remplacez l\'URL pr�sente par celle menant vers votre page � afficher en cas d\'erreur 404.</p>
<form action="./0admin_gestion_404_engine.php?sid=' . session_id() .'" method="POST">
<textarea name="configuration" style="width:95%;height:10em">'.$configuration.'</textarea>
<p><input type="submit" value="Sauvegarder" /></p>
</form>';
fclose($handle);
} else echo "<h1>Erreur : fichier introuvable</h1>
<p>Votre fichier .htaccess est introuvable. Vous devez en cr�er un avant de pouvoir le modifier.</p>";

require("./0admin_footer.php");
?>