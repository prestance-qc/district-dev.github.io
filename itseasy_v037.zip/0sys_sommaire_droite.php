<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");
?>

<!-- FIN ARTICLE -->
<!-- DEBUT SOMMAIRE DROITE -->
</div>
</div>
<div class="droite">

<div class="block_sommaire_droite">
<h1>Informations</h1>
<p>Ces informations sont disponibles sur toutes les pages de votre site.</p>
</div>

<div class="block_sommaire_droite">
<h1>L�gende liens</h1>
<p><img src="./<?php echo $chemin_du_theme ?>/images/lien_interne.png" alt="Lien interne" title="Lien interne" height="12" width="12" />
 : interne
<br />
<img src="./<?php echo $chemin_du_theme ?>/images/lien_sortant.png" alt="Lien sortant" title="Lien sortant" height="12" width="12" />
 : sortant
<br />
<img src="./<?php echo $chemin_du_theme ?>/images/lien_telechargement.png" alt="Lien t�l�chargement" title="Lien t�l�chargement" height="12" width="12" />
 : t�l�chargement
<br />
<img src="./<?php echo $chemin_du_theme ?>/images/langue_anglaise.png" alt="Lien Anglophone" title="Lien Anglophone" height="12" width="12" />
 : Anglophone
<br />
</p>
</div>

</div>
<!-- FIN SOMMAIRE DROITE -->
