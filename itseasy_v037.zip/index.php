<?php
$titre_page = "Accueil";
require("./header.php");
?>

<h1>Bienvenue :o)</h1>
<p>Bonjour et merci d'utiliser Itseasy.
<br />
En cas de probl�me n'h�sitez pas � poser vos questions sur le <a href="http://forum.en1heure.com/">forum Itseasy</a>.</p>
<p><strong>ATTENTION :</strong> � ce stade vous devez d�j� avoir chang� votre login et pass administrateur. Si ce n'est pas le cas, FAITES-LE !</p>

<?php
require("./footer.php");
?>
