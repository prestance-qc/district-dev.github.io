<?php
$titre_page = "Afficher / Masquer les statistiques de bas de page";
require("./0admin_header.php");

// Si le fichier a les bonnes permissions on le modifie sinon on dit ce qu'il faut faire
if(file_exists("./0sys_config.php")) {
if(is_writable("./0sys_config.php") || $os_du_serveur == "windows") {
$handle = fopen("./0sys_config.php","r");
$configuration = fread($handle,filesize("./0sys_config.php"));
fclose($handle);

if($afficher_stats == "0") {
$nouvelle_configuration = str_replace("afficher_stats = \"0\"", "afficher_stats = \"1\"", $configuration);
$handle = fopen("./0sys_config.php","w+");
fwrite($handle,$nouvelle_configuration);
echo "<h1>Op�ration �ffectu�e</h1>
<p>Les statistiques de bas de pages sont maintenant affich�es.</p>";
}

if($afficher_stats == "1") {
$nouvelle_configuration = str_replace("afficher_stats = \"1\"", "afficher_stats = \"0\"", $configuration);
$handle = fopen("./0sys_config.php","w+");
fwrite($handle,$nouvelle_configuration);
echo "<h1>Op�ration �ffectu�e</h1>
<p>Les statistiques de bas de pages sont maintenant d�sactiv�es.</p>";
}
}
else echo "<h1>Permission refus�e</h1>
<p><strong>ATTENTION !</strong> $nom_du_projet n'a pas les autorisations n�cessaires � la de ce fichier. Pour r�soudre ce probl�me changez, � l'aide d'un
client FTP, le <strong>chmod</strong> du fichier en 666 et r�actualisez cette page.</p>

<p><strong>Note :</strong> Tous vos fichiers devraient d�j� avoir un chmod 666. Si ce n'est pas le cas faites-le.</p>";}
else echo "<h1>Erreur : fichier introuvable</h1>
<p>Le fichier de configuration semble introuvable. Si vous voyez quand m�me ce message d'erreur c'est qu'il se passe quelque chose d'extr�mement bizarre
sur votre site o_�
<br />
Merci de nous contacter imm�diatement sur le forum Itseasy.</p>";
require("./0admin_footer.php");
?>
