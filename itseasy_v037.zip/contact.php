<?php
$titre_page = "Nous contacter";
require("./header.php");
?>

<h1>Contacter l'�quipe de <?php echo $nom_du_site ?></h1>
<form action="0sys_contact_engine.php" method="POST">
Votre adresse email :
<br />
<input type="text" name="posteur_mail" size="50" maxlength="50">
<br />
<br />
Sujet de votre mail :
<br />
<input type="text" name="sujet_mail" size="50" maxlength="50">
<br />
<br />
Message � transmettre :
<br />
<textarea name="corps_mail" rows="10" cols="50">Bonjour,</textarea>
<br />
Tous les champs de ce formulaire sont obligatoires.
<br />
<input type="submit" value="Envoyer" />
&nbsp;
<input type="reset" value="Effacer" />
</form>

<?php
require("./footer.php");
?>
