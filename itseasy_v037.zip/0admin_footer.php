<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");
require("./0admin_sommaire_droite.php");
?>
<!-- DEBUT FOOTER -->
<hr class="spacer" />
<div class="footer">[
<acronym title="Extensible HyperText Markup Language">XHTML</acronym> 1 Strict
|
<acronym title="Cascading Style Sheets">CSS</acronym> 2
|
<acronym title="Cascading Style Sheets">WAI</acronym> 2
|
PHP ]</div>
</div>
<!-- MERCI DE RESPECTER NOTRE TRAVAIL : LAISSEZ CE COPYRIGHT -->
<p class="powered">
- [
Powered by <a href="<?php echo $url_du_projet ?>"><?php echo $nom_du_projet ?> v<?php echo $version_du_projet
?></a>
|
Th�me : <?php echo $nom_du_theme ?> par <a href="<?php echo $url_auteur_du_theme ?>"><?php echo $auteur_du_theme ?></a>
] -
<br />
Les informations ne sont donn�es qu'� titre indicatif.
<br />
��<?php echo $nom_du_site ?>, tous droits r�serv�s - Reproduction interdite.</p>
<p class="powered"><a href="./0sys_connexion_administration.php">Administrer <?php echo $nom_du_projet ?></a></p>
</div>
<?php
if($afficher_stats == "1") {
echo "<p class=\"generation\">
[ Page g�n�r�e en ";
$mtime = microtime();
$mtime = explode(" ",$mtime);
$mtime = $mtime[1] + $mtime[0];
$endtime = $mtime;
$gentime = round(($endtime - $starttime) ,$stats_generation_detail);
echo $gentime .
" secondes | Compression gZip active ]\n<br />\nPoids XHTML : "
	 . round((ob_get_length()/1024),2)
	 . " ko ("
	 . (round(filesize("./0admin_header.php")/1024,2)
	 + round(filesize("./0admin_sommaire_gauche.php")/1024,2)
	 + round(filesize(basename($_SERVER['PHP_SELF']))/1024,2)
	 + round(filesize("./0admin_sommaire_droite.php")/1024,2)
	 + round(filesize("./0admin_footer.php")/1024,2))
	 . " ko non compress�)"
	 . " - CSS : "
	 . round((filesize("./$chemin_du_theme/$nom_styles_css.css")/1024),2)
	 . " ko\n<br />\nEl�ments charg�s : "
	 . round(filesize(basename($_SERVER['PHP_SELF']))/1024,2) // VALEUR INCORRECTE : NE TIENS PAS COMPTE DE LA COMPRESSION GZIP :o(
	 . " ko</p>";
}
?>
</body>
</html>

<?php
ob_end_flush();
?>
