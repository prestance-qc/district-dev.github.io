<?php
// Inclusion des fichiers de configuration et d'informations concernant le th�me en cours
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");

// On compresse la page si le navigateur le supporte
@ob_start("ob_gzhandler");

// D�but de la g�n�ration de page pour les statistiques
$mtime = microtime();
$mtime = explode(" ",$mtime);
$mtime = $mtime[1] + $mtime[0];
$starttime = $mtime;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
<title><?php echo $titre_page ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15" />
<meta http-equiv="Content-language" content="fr" />
<meta name="robots" content="follow, index, all" />
<meta name="revisit-after" content="1 day" />
<meta name="description" content="<?php echo $meta_description ?>" />
<meta name="keywords" content="<?php echo $meta_keywords ?>" />
<meta name="author" content="<?php echo $meta_author ?>" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo "./$chemin_du_theme/$nom_styles_css.css" ?>" />
</head>

<body>
<div class="structure">
<div class="conteneur">
<div class="header">
<?php
// Ici on d�termine la hauteur et la largeur du logo du site pour afficher les valeurs dans le code XHTML
@list($largeur_titre, $hauteur_titre) = getimagesize("./".$chemin_du_theme."/images/titre.png");
?>
<img src="./<?php echo $chemin_du_theme ?>/images/titre.png" alt="<?php echo $nom_du_site ?>" title="<?php echo $nom_du_site ?>" height="<?php echo $hauteur_titre ?>" width="<?php echo $largeur_titre ?>" />
</div>
<!-- FIN HEADER -->
<?php
// On r�cup�re le nom de la page pour si c'est la page de connexion � l'admin
// On v�rifie si le site est ferm�. Si oui il faut quand m�me afficher la page de connexion � l'admin
if(basename($_SERVER['PHP_SELF']) != "0sys_connexion_administration.php") {
if($fermeture_du_site == "1") die(require("./0sys_site_temporairement_ferme.php"));
};

// Inclusion du sommaire gauche
require("./0sys_sommaire_gauche.php");
?>
