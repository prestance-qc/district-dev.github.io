<?php
$titre_page = "G�n�ration de votre nouvelle page";
require("./0admin_header.php");

//On traite le titre de la page pour en faire le nom de fichier
$_POST['nom_fichier'] = strtolower($_POST['titre_page']);
$_POST['nom_fichier'] = stripslashes($_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("!", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("?", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(":", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(";", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("&", "-", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("\"", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("'", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(" - ", "-", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("^", "+", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(" ", "_", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("\'", "", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("/", "-", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(".", "-", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(",", "_", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("__", "_", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "e", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "e", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "e", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "a", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "a", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "u", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "u", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "o", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("�", "e", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace("(", "-", $_POST['nom_fichier']);
$_POST['nom_fichier'] = str_replace(")", "-", $_POST['nom_fichier']);

// On traite le titre de la page et le message pour enlever les �chapements
$_POST['titre_page'] = stripslashes($_POST['titre_page']);
$_POST['message'] = stripslashes($_POST['message']);

// Pr�visualisation de l'article
if($_POST['preview'] == "Pr�visualisation") {
echo "
<h1>Pr�visualisation</h1>";
echo "<p><strong>Titre de la page :</strong>" . $_POST['titre_page'] . "</p>
<div class=\"previsualisation\">";
$_POST['message'] = stripslashes($_POST['message']);
echo $_POST['message'] . "
</div>
<p><strong>Nom du fichier g�n�r� :</strong>" . $_POST['nom_fichier'] . ".php</p>
<p><a href=\"javascript:history.back()\">Revenir au formulaire d'ajout de page.</a></p>";
}

// Si on a la permission on �crit sinon on ne le fait pas
if(is_writable("./") || $os_du_serveur == "windows") {
$_POST['message'] =
"<?php
$"."titre_page=\"" . $_POST['titre_page'] . "\";
require(\"./header.php\");
?>

".$_POST['message']."

<?php
require(\"./footer.php\");
?>";

$handle = fopen("./".$_POST['nom_fichier'] . ".php", "w");
fwrite($handle, $_POST['message']);
fclose($handle);
echo "<h1>Votre page a bien �t� cr�e</h1>
<p><strong>Nom du fichier g�n�r� :</strong> <a href=" . $_POST['nom_fichier'] . ".php>" . $_POST['nom_fichier'] . ".php</a></p>
<p>Code � ins�rer dans le menu de gauche pour ajouter le lien :
<h2>Pour une cat�gorie</h2>
<pre><code>&lt;p&gt;&lt;a href=\"./$_POST[nom_fichier].php\"&gt; &lt;/a&gt;&lt;/p&gt;</code></pre>
<h2>Pour une sous-cat�gorie</h2>
<pre><code>&lt;li&gt;&lt;a href=\"./$_POST[nom_fichier].php\"&gt; &lt;/a&gt;&lt;/li&gt;</code></pre>";
}
else {
echo "<h1>Permission refus�e</h1>
<p>$nom_du_projet n'a pas les autorisations n�cessaires � la cr�ation d'une nouvelle page dans le r�pertoire. Pour r�soudre ce probl�me changez, � l'aide d'un
client FTP, le <strong>chmod</strong> du dossier contenant $nom_du_projet en 777 et r�actualisez cette page.</p>";
}
require("./0admin_footer.php");
?>