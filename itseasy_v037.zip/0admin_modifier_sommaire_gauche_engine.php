<?php
$titre_page = "Modification du sommaire de gauche";
require("./0admin_header.php");

// Si le fichier a les bonnes permissions on le modifie sinon on dit ce qu'il faut faire
if(file_exists("./0sys_sommaire_gauche.php")) {
if(is_writable("./0sys_sommaire_gauche.php") || $os_du_serveur == "windows") {
$handle = fopen("./0sys_sommaire_gauche.php","w+");
$_POST['message'] = stripslashes($_POST['message']);
fwrite($handle,$_POST['message']);
echo "<h1>Modification effectu�e</h1>
<p>Votre message a bien �t� mise � jour.</p>";
fclose($handle);
}
else echo "<h1>Permission refus�e</h1>
<p><strong>ATTENTION !</strong> $nom_du_projet n'a pas les autorisations n�cessaires � la de ce fichier. Pour r�soudre ce probl�me changez, � l'aide d'un
client FTP, le <strong>chmod</strong> du fichier en 666 et r�actualisez cette page.</p>

<p><strong>Note :</strong> Tous vos fichiers devraient d�j� avoir un chmod 666. Si ce n'est pas le cas faites-le.</p>";}

else echo "<h1>Erreur : fichier introuvable</h1>
<p>Le fichier est introuvable dans votre dossier.</p>";
require("./0admin_footer.php");
?>