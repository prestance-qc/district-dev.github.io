<?php
// On r�inclu les fichiers de configuration pour �tre sur de ne pas avoir de variables "sensibles"
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");

// On r�cup�re le nom de la page pour savoir si c'est la page de connexion � l'admin
// On v�rifie si le site est ferm�. Si oui il faut quand m�me afficher la page de connexion � l'admin
if($fermeture_du_site != "1") require("./0sys_sommaire_droite.php");
if(basename($_SERVER['PHP_SELF']) == "0sys_connexion_administration.php" && $fermeture_du_site == "1") require("./0sys_sommaire_droite.php");
?>
<!-- DEBUT FOOTER -->
<hr class="spacer" />
<div class="footer">[
<acronym title="Extensible HyperText Markup Language">XHTML</acronym> 1 Strict
|
<acronym title="Cascading Style Sheets">CSS</acronym> 2
|
<acronym title="Cascading Style Sheets">WAI</acronym> 2
|
PHP ]</div>
</div>
<!-- MERCI DE RESPECTER MON TRAVAIL BENEVOLE EN LAISSANT CE COPYRIGHT -->
<p class="powered">
- [
Powered by <a href="<?php echo $url_du_projet ?>"><?php echo $nom_du_projet ?> v<?php echo $version_du_projet
?></a>
|
Th�me : <?php echo $nom_du_theme ?> par <a href="<?php echo $url_auteur_du_theme ?>"><?php echo $auteur_du_theme ?> | <a href="http://www.cuisinetoo.com">recettes faciles</a>
] -
<br />
Les informations ne sont donn�es qu'� titre indicatif.
<br />
��<?php echo $nom_du_site ?>, tous droits r�serv�s - Reproduction interdite.</p>
<p class="powered"><a href="./0sys_connexion_administration.php">Administrer <?php echo $nom_du_projet ?></a></p>
</div>

<?php
// Et si les stats sont affich�es on les calcule et on g�re le rendu
// N'est vraiment utile que pour les tests
if($afficher_stats == "1") {
echo "<p class=\"generation\">
[ Page g�n�r�e en ";
$mtime = microtime();
$mtime = explode(" ",$mtime);
$mtime = $mtime[1] + $mtime[0];
$endtime = $mtime;
$gentime = round(($endtime - $starttime) ,$stats_generation_detail);
echo $gentime .
" secondes | Compression gZip active ]\n<br />\nPoids XHTML : "
	 . round((ob_get_length()/1024),2)
	 . " ko ("
	 . (round(filesize("./header.php")/1024,2)
	 + round(filesize("./0sys_sommaire_gauche.php")/1024,2)
	 + round(filesize(basename($_SERVER['PHP_SELF']))/1024,2)
	 + round(filesize("./0sys_sommaire_droite.php")/1024,2)
	 + round(filesize("./footer.php")/1024,2))
	 . " ko non compress�)"
	 . " - CSS : "
	 . round((filesize("./$chemin_du_theme/$nom_styles_css.css")/1024),2)
	 . " ko\n<br />\nEl�ments charg�s : "
	 . round(filesize(basename($_SERVER['PHP_SELF']))/1024,2) // VALEUR INCORRECTE : NE TIENS PAS COMPTE DE LA COMPRESSION GZIP :o(
	 . " ko</p>";
}
?>
</body>
</html>

<?php
ob_end_flush();
?>
