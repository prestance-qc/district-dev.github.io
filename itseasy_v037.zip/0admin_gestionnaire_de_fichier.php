<?php
$titre_page = "Gestionnaire de fichiers";
require("./0admin_header.php");
?>

<h1>Gestionnaire de fichiers</h1>
<p>Pour vous aider � vous y retrouver, les fichiers amdinistration sont teint�s en rouge, les fichiers syst�me en vert et vos fichiers personnels (qui
ne font pas partie d'<?php echo $nom_du_projet ?> mais de votre site) sont en fond blanc.</p>
<table>
<tr>
<th>Nom du fichier</th>
<th colspan="4">Action</th>
</tr>

<?php
// On d�finit le type de variable
settype($i, "integer");

// On cr�e un tableau avec toutes les entr�es
$array = array();
$handle_thumbs = opendir(".");
while ($file = readdir($handle_thumbs)) {
if ($file != "." && $file != ".." && is_dir($file) != "FALSE") {
$array[] = $file;
$i++;
}
}
closedir($handle_thumbs);
sort($array);
for($i = 0; $i != count($array); $i++) {

// On affiche tout �a en couleur avec les zolis boutons
if(ereg("0admin_", $array[$i])) $class = " class=\"admin\"";
else $class = "";
if(ereg("0sys_", $array[$i]) || $array[$i] == ".htaccess") $class = " class=\"system\"";
echo "<tr>
<td$class><a href=\"./$array[$i]\" title=\"Ex�cuter le fichier $array[$i]\">$array[$i]</a></td>
<td><a href=\"./0admin_informations_sur_un_fichier.php?sid=" . session_id() . "&file=$array[$i]\"><img src=\"$chemin_du_theme/images/infos.png\" alt=\"Informations sur $array[$i]\" title=\"Informations sur $array[$i]\" /></a></td>
<td><a href=\"./0admin_renommer_un_fichier.php?sid=" . session_id() . "&file=$array[$i]\"><img src=\"$chemin_du_theme/images/renommer.png\" alt=\"Renommer $array[$i]\" title=\"Renommer $array[$i]\" /></a></td>
<td><a href=\"./0admin_modifier_un_fichier.php?sid=" . session_id() . "&file=$array[$i]\"><img src=\"$chemin_du_theme/images/modifier.png\" alt=\"Modifier $array[$i]\" title=\"Modifier $array[$i]\" /></a></td>
<td><a href=\"./0admin_supprimer_un_fichier.php?sid=" . session_id() . "&file=$array[$i]\"><img src=\"$chemin_du_theme/images/effacer.png\" alt=\"Supprimer $array[$i]\" title=\"Supprimer $array[$i]\" /></a></td></tr>\n";
}
?>
</table>
<p>Soit un total de <?php echo $i ?> fichiers.</p>

<?php
require("./0admin_footer.php");
?>