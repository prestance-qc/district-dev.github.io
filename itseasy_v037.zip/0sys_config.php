<?php
/*---------------------------------------------------------------------------------------------------
  Fichier de configuration
  ATTENTION : Si vous voulez mettre des guillemets
  placez un \ avant.
  
  Exemple :
  $meta_author = "St�pahane alias \"Steph\"";
    --
  La valeur 0 (z�ro) correspond � une d�sactivation
  La valeur 1 (un) correspond � une activation
---------------------------------------------------------------------------------------------------*/

//FICHIER DE CONFIGURATION, N'Y TOUCHEZ PAS MANUELLEMENT A MOINS DE SAVOIR CE QUE VOUS FAITES

require("./0sys_config_perso.php");
## NE SURTOUT PAS TOUCHER A CETTE LIGNE
$hash_acces = md5($login_admin . $pass_admin);

# Type d'OS sur le serveur. D�commentez la ligne Windows pour le faire tourner avec EasyPHP
# Recommentez la ligne pour l'utiliser chez votre h�bergeur
$os_du_serveur = "linux";
//$os_du_serveur = "windows";

# Etre pr�venu par mail de toute connexion et tentative de connexion �chou�e � la partie administration
# Si vous d�sactivez cette fonction vous ne serez inform� que des tentatives �chou�es (recommand�)
$toute_connexion_signalee = "0";

## Configuration technique
# Afficher les statistiques en bas de page (temps de g�n�ration des pages, poids, etc.)
# D�faut : 1
$afficher_stats = "0";
# Nombre de chiffres apr�s la virgule pour le temps de g�n�ration des pages
# D�faut : 5
$stats_generation_detail = "5";
# Autoriser les visiteurs � voir votre adresse email mais uniquement en cas de disfonctionnement de la fonction mail)
# D�faut : 1
$autoriser_public_mail = "1";

## Fermeture de votre site
# Fermer votre site ?
$fermeture_du_site = "0";
$date_fermeture = "22/08/2004";
$heure_fermeture = "23:16";

## MERCI DE NE PAS MODIFIER CES INFORMATIONS DE COPYRIGHT
$nom_du_projet = "Itseasy";
$url_du_projet = "http://www.en1heure.com/itseasy/";
$version_du_projet = "0.3.7";
?>