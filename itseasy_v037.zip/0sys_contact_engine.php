<?php
$titre_page = "Nous contacter";
require("./header.php");

// On d�finit la variable $nb_erros et on v�rifie s'il y a des erreurs
settype($nb_errors, "integer");

if($_POST['posteur_mail'] == "") {
$errors = "<span class=\"red\">Vous n'avez pas entr� votre adresse email</span>\n<br />\n";
$nb_errors++;
}

if($_POST['sujet_mail'] == "") {
$errors = $errors . "<span class=\"red\">Vous n'avez pas entr� de sujet pour votre email</span>\n<br />\n";
$nb_errors++;
}

if($_POST['corps_mail'] == "") {
$errors = $errors . "<span class=\"red\">Vous n'avez pas entr� de message pour votre email</span>\n<br />\n";
$nb_errors++;
}

if($_POST['corps_mail'] == "Bonjour,") {
$errors = $errors . "<span class=\"red\">Vous n'avez pas entr� de message pour votre email</span>\n<br />\n";
$nb_errors++;
}

// S'il y a des erreurs on les affiche et on affiche ce qui a �t� entr�
if($nb_errors != 0)
echo "<h1>Attention : $nb_errors erreur(s) rencontr�es</h1>
<p>$errors</p>
<hr />
<h1>Voici le message que vous avez tap�</h1>
<p>Votre adresse :
<br />
" .$_POST['posteur_mail'] . "</p>
<p>Sujet :
<br />
" . $_POST['sujet_mail'] . "
<p>Message :
<br />
" . $_POST['corps_mail'] . "</p>";

settype($fonction_mail_error, "integer");

// Y�bon on peut traiter le mail
if($nb_errors == 0) {
$_POST['corps_mail'] = stripslashes($_POST['corps_mail']);
// Correction de coc
$expediteur = ;
mail("$email_webmaster",
$_POST['sujet_mail'],
$_POST['corps_mail'],
"From: $expediteur \r\nReply-To: $expediteur") or $fonction_mail_error++;
}

// Une erreur inconnue a �t� trouv�e... Le serveur ne g�re pas la fonction mail() ?
// On affiche l'adresse courriel du webmestre pour que l'utilisateur puisse quand m�me le contacter
if($fonction_mail_error == 1) {
echo "<h1>Erreur inattendue</h1>
<p>Votre message n'a pas pu �tre envoy� pour une raison inconue :S
<br />
Veuillez nous en excuser.</p>";
if($autoriser_public_mail == 1) echo "<p>Vous pouvez envoyer le message � cette adresse <a href=\"mailto:vous@domaine.com\">$email_webmaster</a></p>
<hr />
<h1>Voici le message que vous avez tap�</h1>
<p>Votre adresse :
<br />
" . $_POST['posteur_mail'] . "</p>
<p>Sujet :
<br />
" . $_POST['sujet_mail'] . "
<p>Message :
<br />
" . $_POST['corps_mail'] . "</p>";
}

// C'est envoy� :o)
if($nb_errors == 0) if($fonction_mail_error == 0) echo "<h1>Message envoy�</h1>
<p>Votre message a correctement �t� envoy�. Nous y r�pondrons dans les plus brefs d�lais.</p>
<p>Merci, l'�quipe $nom_du_projet</p>";

require("./footer.php");
?>
