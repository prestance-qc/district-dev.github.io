<?php
$titre_page = "Informations sur un fichier";
require("./0admin_header.php");
?>

<h1>Informations sur <?php echo $_GET['file'] ?></h1>
<table>
<?php
if(file_exists($_GET['file'])) {
echo "<tr><td>Poids du fichier :</td><td> " . round(filesize($_GET['file'])/1024,2) . " ko</td></tr>
<tr><td>Date de cr�ation * :</td><td> " . date("d/m/Y � H:i", filectime($_GET['file'])) . "</td></tr>
<tr><td>Date de derni�re modification :</td><td> " . date("d/m/Y � H:i", filemtime($_GET['file'])) . "</td></tr>
<tr><td>Date du dernier acces :</td><td> " . date("d/m/Y � H:i", fileatime($_GET['file'])) . "</td></tr>
</table>
<p><em>* ou de derni�re modification de permissions.</em></p>";
} else echo "<h1>Erreur : fichier invalide</h1>
<p>Vous devez sp�cifier un fichier valide.</p>";

require("./0admin_footer.php");
?>