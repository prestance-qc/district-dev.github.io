<?php
$titre_page = "Index de l'administration";
require("./0sys_config.php");

// On v�rifie ici que les informations sont ok pour acc�der � l'admin
// Il faut de plus que le type soit pass� par la page de connexion sinon c'est louche

session_start();
$_SESSION['login_utilisateur'] = $_POST['login_utilisateur'];
$_SESSION['pass_utilisateur'] = $_POST['pass_utilisateur'];
$_SESSION['hash_acces_utilisateur'] = md5($_POST['login_utilisateur'] . $_POST['pass_utilisateur']);

if($_SESSION['hash_acces_utilisateur'] == $hash_acces) {
$_SESSION['ip_utilisateur'] = $_SERVER['REMOTE_ADDR'];
$_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
header("Location:./0admin_index.php?sid=" . session_id());
exit();
}
else require("./0sys_autorisation_refusee.php");
?>