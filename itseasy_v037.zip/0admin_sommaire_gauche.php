<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");
?>
<!-- DEBUT SOMMAIRE GAUCHE -->
<div class="gauche">

<div class="block_sommaire_gauche">
<p><a href="./index.php" title="Revenir � la page d'accueil">Accueil</a></p>
</div>

<?php
// G�n�re les liens du panneau administration dans le sommaire gauche
if(basename($_SERVER['PHP_SELF']) != "connexion_administration.php")
echo "<div class=\"block_sommaire_gauche\">
<p><a href=\"./0admin_index.php?sid=" . session_id() . "\" title=\"Index de l'administration\">Administration</a></p>
<ul>
<li><a href=./0admin_index.php?sid=" . session_id() . "#gestion_site>Gestion site</a></li>
<li><a href=./0admin_index.php?sid=" . session_id() . "#communication>Communication</li>
<li><a href=./0admin_index.php?sid=" . session_id() . "#configuration_technique>Technique</li>
</ul>
<p><a href=\"./0admin_deconnexion.php?sid=" . session_id() . "\" title=\"D�connexion forc�e de la partie administration\">D�connexion</a></p>
</div>";
?>
</div>

<div class="article">
<div class="contenu_article">
<!-- FIN SOMMAIRE GAUCHE -->
<!-- DEBUT ARTICLE -->