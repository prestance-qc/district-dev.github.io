<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");
?>
<!-- DEBUT SOMMAIRE GAUCHE -->
<div class="gauche">

<div class="block_sommaire_gauche">
<p><a href="./index.php">Accueil</a></p>
<ul>
<li>Lien</li>
<li>Lien</li>
</ul>
<p><a href="./contact.php">Contact</a></p>
</div>

</div>
<div class="article">
<div class="localisation">Vous �tes ici :
<?php
// On r�cup�re le titre de la page et le nom de celle-ci pour l'afficher dans le "Vous �tes ici"
$url_de_la_page = basename($_SERVER['PHP_SELF']);
echo '<a href="./'.$url_de_la_page.'">'. $titre_page .'</a>';
?>
</div>
<div class="contenu_article">
<!-- FIN SOMMAIRE GAUCHE -->
<!-- DEBUT ARTICLE -->