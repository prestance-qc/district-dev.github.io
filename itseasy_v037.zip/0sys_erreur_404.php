<?php
$titre_page = "Erreur 404";
require("./header.php");
?>

<h1>Erreur 404 / Page non trouv�e :o(</h1>
<p>La page que vous demandez n'existe pas. Peut �tre a-t-elle �t� supprim�e ou d�plac�e.</p>
<p>Si vous pensez que cette erreur n'aurait pas du se produire (par exemple dans le cas o� elle r�sulte d'un lien mort)
merci de <a href="./contact.php">contacter le Webmaster</a> pour l'en informer.</p>

<?php
require("./footer.php");
?>
