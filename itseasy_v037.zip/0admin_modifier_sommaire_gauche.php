<?php
$page_edition_html = "1";
$titre_page = "Modification du sommaire de gauche";
require("./0admin_header.php");

if(!file_exists("./0sys_sommaire_gauche.php")) {
echo "<h1>Erreur : fichier introuvable</h1>
<p>Vous essayez de modifier un fichier qui n'existe pas !</p>";
require("./0admin_footer.php");
exit();
}

$handle = fopen("./0sys_sommaire_gauche.php","r");
$configuration = fread($handle,filesize("./0sys_sommaire_gauche.php"));
$configuration = stripslashes($configuration);
?>
<h1>Modification du sommaire de gauche</h1>
<p>Vous pouvez ici modifier le contenu du sommaire de gauche de votre site.</p>

<form action="./0admin_modifier_sommaire_gauche_engine.php?sid=<?php echo session_id() ?>" method="post" name="post" onsubmit="return checkForm(this)">
<input type="button" name="addbbcode6" value="H1" onclick="bbstyle(6)" onmouseover="helpline('h1')" />
<input type="button" name="addbbcode8" value="�" onclick="bbstyle(8)" onmouseover="helpline('paragraphe')" />
<input type="button" name="addbbcode0" value="Gras" style="font-weight:bold;" onclick="bbstyle(0)" onmouseover="helpline('gras')" />
<input type="button" name="addbbcode2" value="Italique" style="font-style:italic;" onclick="bbstyle(2)" onmouseover="helpline('italique')" />
<input type="button" name="addbbcode4" value="Quote" style="text-decoration:underline;" onclick="bbstyle(4)" onmouseover="helpline('souligne')" />
<input type="button" name="addbbcode14" value="Image" onclick="bbstyle(14)" onmouseover="helpline('image')" />
<input type="button" name="addbbcode10" value="Liste" onclick="bbstyle(10)" onmouseover="helpline('liste')" />
<input type="button" name="addbbcode12" value="Li" onclick="bbstyle(12)" onmouseover="helpline('li')" />
<br />
<input type="button" name="addbbcode20" value="Table" onclick="bbstyle(20)" onmouseover="helpline('table')" />
<input type="button" name="addbbcode22" value="tr" onclick="bbstyle(22)" onmouseover="helpline('tr')" />
<input type="button" name="addbbcode24" value="th" onclick="bbstyle(24)" onmouseover="helpline('th')" />
<input type="button" name="addbbcode26" value="td" onclick="bbstyle(26)" onmouseover="helpline('td')" />
<input type="button" name="addbbcode18" value="<?php echo $nom_du_site ?>" onclick="bbstyle(18)" onmouseover="helpline('nom_site')" />
<br />
<input type="button" name="addbbcode16" value="Lien" onclick="bbstyle(16)" onmouseover="helpline('lien')" />
<input type="button" name="addbbcode28" value="Interne" onclick="bbstyle(28)" onmouseover="helpline('lien_interne')" />
<input type="button" name="addbbcode30" value="Sortant" onclick="bbstyle(30)" onmouseover="helpline('lien_sortant')" />
<input type="button" name="addbbcode32" value="T�l�chargement" onclick="bbstyle(32)" onmouseover="helpline('lien_telechargement')" />
<input type="button" name="addbbcode34" value="Anglophone" onclick="bbstyle(34)" onmouseover="helpline('lien_anglophone')" />
<br />
<input type="text" name="helpbox" size="45" maxlength="100" class="bb_area" readonly="readonly" />
<br />
<textarea name="message" rows="20" cols="35" class="bb_area" tabindex="3" class="post" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);">
<?php
echo $configuration
?>
</textarea>
<br />
<a href="javascript:bbstyle(-1)">Fermer les balises</a>
<br />
<input type="submit" value="Envoyer" name="confirm" />
<input type="reset" value="R�tablir le fichier" /></p>
</form>

<?php
fclose($handle);
require("./0admin_footer.php");
?>