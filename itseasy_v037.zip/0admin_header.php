<?php
require("./0sys_config.php");
require("./$chemin_du_theme/theme_info.php");

// All� on v�rifie chaque point de s�curit� pour savoir si l'utilisateur peut acc�der � la page
session_start();
if(!isset($_SESSION['ip_utilisateur'])) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if($_SESSION['ip_utilisateur'] != $_SERVER['REMOTE_ADDR']) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if(!isset($_SESSION['hash_acces_utilisateur'])) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if($_SESSION['hash_acces_utilisateur'] != $hash_acces) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if(!isset($_GET['sid'])) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if($_GET['sid'] != session_id()) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if(!isset($_SESSION['user_agent'])) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

if($_SESSION['user_agent'] != $_SERVER['HTTP_USER_AGENT']) {
$titre_page = "Autorisation refus�e";
require("./0sys_autorisation_refusee.php");
exit();
};

@ob_start("ob_gzhandler");

$mtime = microtime();
$mtime = explode(" ",$mtime);
$mtime = $mtime[1] + $mtime[0];
$starttime = $mtime;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
<title><?php echo $titre_page ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15" />
<meta http-equiv="Content-language" content="fr" />
<meta name="robots" content="follow, index, all" />
<meta name="revisit-after" content="1 day" />
<meta name="description" content="<?php echo $meta_description ?>" />
<meta name="keywords" content="<?php echo $meta_keywords ?>" />
<meta name="author" content="<?php echo $meta_author ?>" />
<?php
settype($page_edition_html, "integer");
if($page_edition_html == "1") echo "<script language=\"JavaScript\" type=\"text/javascript\" src=\"0sys_bbcode.js\"></script>";
?>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo "./$chemin_du_theme/$nom_styles_css.css" ?>" />
</head>

<body>
<div class="structure">
<div class="conteneur">
<div class="header">
<?php
@list($largeur_titre, $hauteur_titre) = getimagesize("./".$chemin_du_theme."/images/titre.png");
?>
<img src="./<?php echo $chemin_du_theme ?>/images/titre.png" alt="<?php echo $nom_du_site ?>" title="<?php echo $nom_du_site ?>" height="<?php echo $hauteur_titre ?>" width="<?php echo $largeur_titre ?>" />
</div>
<!-- FIN HEADER -->
<?php
require("./0admin_sommaire_gauche.php");
?>