<?php
$titre_page = "Index de l'administration";
require("./0admin_header.php");
?>

<h1>Panneau d'administration <?php echo $nom_du_projet . "&nbsp;" . $version_du_projet ?></h1>
<div class="marge_h2">
<h2><a name="gestion_du_site">Gestion du site</a></h2>
<ul>
<li><a href="./0admin_creer_une_page.php?sid=<?php echo session_id() ?>">Cr�er une nouvelle page</a></li>
<li><a href="./0admin_gestionnaire_de_fichier.php?sid=<?php echo session_id() ?>">Gestionnaire de fichiers</a></li>
<li><a href="./0admin_modifier_sommaire_gauche.php?sid=<?php echo session_id() ?>">Modifier le sommaire de gauche</a></li>
<li><a href="./0admin_modifier_sommaire_droite.php?sid=<?php echo session_id() ?>">Modifier le sommaire de droite</a></li>
<li><a href="./0admin_modifier_style_css.php?sid=<?php echo session_id() ?>">Modifier le style CSS de <?php echo $nom_du_theme ?></a></li>
</ul>

<h2><a name="communication">Communication</a></h2>
<ul>
<li><a href="./0admin_modifier_bloc_note.php?sid=<?php echo session_id() ?>">Laisser un message dans le bloc-note</a></li>
</ul>

<h2><a name="configuration_technique">Configuration technique</a></h2>
<ul>
<?php
if($afficher_stats == "0") echo "<li><a href=\"./0admin_afficher_masquer_statistiques.php?sid=" . session_id() . "\">Afficher les statistiques en bas de page</a></li>";
if($afficher_stats == "1") echo "<li><a href=\"./0admin_afficher_masquer_statistiques.php?sid=" . session_id() . "\">Masquer les statistiques en bas de page</a></li>";
?>
<li><a href="./0admin_gestion_404.php?sid=<?php echo session_id() ?>">Gestion des erreurs 404</a></li>
<?php
if($fermeture_du_site == "0") echo "<li><a href=\"./0admin_fermer_le_site.php?sid=" . session_id() . "\">Fermer temporairement le site</a></li>";
if($fermeture_du_site == "1") echo "<li><a href=\"./0admin_fermer_le_site.php?sid=" . session_id() . "\">R�ouvrir le site</a></li>";
?>
</ul>
</div>

<hr />

<h1>Communaut� <?php echo $nom_du_projet ?></h1>
<p>Soyez li�s � la communaut� et aidez l� � se developper ! Pour soumettre un bug, une faille de s�curit� ou faire une demande d'ajout de fonction
retrouvez-nous sur <a href="http://forum.en1heure.com/">le forum du r�seau En1heure</a>.
</ul>

<?php
require("./0admin_footer.php");
?>