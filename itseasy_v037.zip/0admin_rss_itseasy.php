<?php
// Ce parseur XML est l'oeuvre de Tuyauman, merci :o)
function rss()
{
   $fichier = "http://www.en1heure.com/itseasy/itseasy.rss";
   $bleah="";
    function fonctionBaliseOuvrante($parseur, $nomBalise, $tableauAttributs)
    {
         global $derniereBaliseRencontree;
        $derniereBaliseRencontree = $nomBalise;
    }

    function fonctionBaliseFermante($parseur, $nomBalise)
    {
        global $derniereBaliseRencontree;
        global $titre;
        global $lien;
        global $description;      

        switch ($nomBalise) {
            case "CHANNEL" :
                $titre = "";
                $lien = "";
                break;
            case "ITEM" :
            //Ligne a modifier pour personaliser l'affichage
                echo "<h1><a href=\"$lien\">$titre</a></h1>
<p>$description</p>";
                $titre = "";
                $lien = "";
                break;
        }
        $derniereBaliseRencontree = "";
    }
    function fonctionTexte($parseur, $texte)
    {
        global $derniereBaliseRencontree;
        global $titre;
        global $lien;
        global $description;      

        switch ($derniereBaliseRencontree) {
            case "TITLE":
                $titre = $texte;
                break;
            case "LINK":
                $lien = $texte;
                break;
         case "DESCRIPTION":
                $description = $texte;
                break;
        }       
    }

    $parseurXML = xml_parser_create();
    xml_set_element_handler($parseurXML, "fonctionBaliseOuvrante"
                                       , "fonctionBaliseFermante");
    xml_set_character_data_handler($parseurXML, "fonctionTexte");
    $fp = fopen($fichier, "r");
    if (!$fp) die("Impossible d'ouvrir le fichier XML");
    while ( $ligneXML = fgets($fp, 1024)) {
        xml_parse($parseurXML, $ligneXML, feof($fp)) or
            die("Erreur XML");
   }
   
    xml_parser_free($parseurXML);
    fclose($fp);
}
?>
