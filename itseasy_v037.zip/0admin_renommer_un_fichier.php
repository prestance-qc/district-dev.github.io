<?php
$titre_page = "Renommer le fichier" . $_GET['file'];
require("./0admin_header.php");
if(!file_exists($_GET['file'])) {
echo "<h1>Erreur : fichier introuvable</h1>
<p>Le fichier demand� est introuvable.</p>";
require("./0admin_footer.php");
exit();
}
?>

<h1>Renommer le fichier <?php echo $_GET['file'] ?></h1>
<p>Veuillez entrer le nouveau nom pour le fichier <strong><?php echo $_GET['file'] ?></strong> :</p>
<form action="0admin_renommer_un_fichier_engine.php?sid=<?php echo session_id() ?>&file=<?php echo $_GET['file'] ?>" method="POST">
<input type="text" name="nom_du_fichier" value="<?php echo $_GET['file'] ?>" size="50" /> <input type="submit" value="Ok" />
</form>

<?php
require("./0admin_footer.php");
?>