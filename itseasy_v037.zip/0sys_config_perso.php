<?php
/*---------------------------------------------------------------------------------------------------
  Fichier de configuration
  ATTENTION : Si vous voulez mettre des guillemets
  placez un \ avant.
  
  Exemple :
  $meta_author = "St�pahane alias \"Steph\"";
    --
  La valeur 0 (z�ro) correspond � une d�sactivation
  La valeur 1 (un) correspond � une activation
---------------------------------------------------------------------------------------------------*/

## Balises META ( /!\ Laissez les sur une seule ligne pour que les robots puissent les prendre en compte)
# Les balises META n'ont qu'une importance limit�e, optimisez surtout le titre de vos pages pour �tre bien r�f�renc�
$meta_description = "Description de votre site";
$meta_keywords = "mots, clefs, pour, les, annuaires";
$meta_author = "NOM Pr�nom";

## Informations relatives � votre site
$nom_du_site = "Mon site";
$url_du_site = "http://www.domaine.com/";
$email_webmaster = "vous@domaine.com";
$chemin_du_theme = "themes/lightblue";

## Configuration pour la m�t�o dans l'administration
$numero_de_departement = "59";

## Acc�s partie administration
$login_admin = "login";
$pass_admin = "pass";
?>