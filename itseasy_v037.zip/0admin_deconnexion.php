<?php
$titre_page = "D�connexion de l'administration";
require("./0admin_header.php");

// On supprime la session
session_unset();
session_destroy();
?>

<h1>D�connexion de l'administration</h1>
<p>La d�connexion a bien �t� �ffectu�e.</p>

<?php
require("./0admin_footer.php");
?>