<?php
$titre_page = "Connexion � l'espace d'administration";
require("./header.php");

// On v�rifie si l'utilisateur n'est pas d�j� logu� en Administrateur
// On v�rifie son IP, son mot de passe et login et son user_agent
// Si oui on le m�ne � l'administration, si non il se connecte
session_start();
if(isset($_SESSION['ip_utilisateur'])
&&
$_SESSION['ip_utilisateur'] == $_SERVER['REMOTE_ADDR']
&&
isset($_SESSION['hash_acces_utilisateur'])
&&
$_SESSION['hash_acces_utilisateur'] == $hash_acces
&&
isset($_SESSION['user_agent'])
&&
$_SESSION['user_agent'] == $_SERVER['HTTP_USER_AGENT']) {
header("Location:./0admin_index.php?sid=" . session_id());
exit();
};
?>

<h1>Identifiez vous pour administrer <?php echo $nom_du_site ?></h1>
<form action="./0admin_verification_connexion.php" method="POST">
<p>Login :
<br />
<input type="text" name="login_utilisateur" />
<br />
Mot de passe :
<br />
<input type="password" name="pass_utilisateur" />
<input type="submit" value="Connexion" /></p>
</form>
<p><strong>Vous �tes <?php echo $_SERVER['REMOTE_ADDR'] . " @ " . date("H:i:s") . " le " . date("d/m/Y") ?></strong>
<br />
<?php
if($toute_connexion_signalee == "1") echo "Toute connexion ou tentative de connexion est notifi�e, de mani�re d�taill�e, � l'Administrateur de ce site.";
else echo "Toute tentative de connexion �chou�e est notifi�e, de mani�re d�taill�e, � l'Administrateur de ce site.";
?></p>

<hr />

<h1>Mise en garde</h1>
<p>Veuillez prendre connaissance de la loi Fran�aise relative � la fraude Informatique.</p>

<h2>Loi n� 88-19 du 5 janvier 1988</h2>
<p>L'Assembl�e Nationale et le S�nat ont adopt�, le pr�sident de la R�publique promulgue la loi dont la teneur suit :</p>

<p><strong>Article 462-2</strong>
<br />
Quiconque, frauduleusement, aura acc�d� ou se sera 
maintenu dans tout ou partie d'un syst�me de traitement 
automatis� de donn�es sera puni d'un emprisonnement de 
deux mois � un an et d'une amende de 2.000 F � 50.000 F 
ou de l'une de ces deux peines. Lorsqu'il en sera r�sult� soit la 
suppression ou la modification de donn�es contenues dans 
le syst�me, soit une alt�ration du fonctionnement de ce 
syst�me, l'emprisonnement sera de deux mois � deux ans 
et l'amende de 10.000 F � 100.000 F.</p>

<p><strong>Article 462-3</strong>
<br />
Quiconque aura, intentionnellement et au m�pris des 
droits d'autrui, entrav� ou fauss� le fonctionnement 
d'un syst�me de traitement automatis� de donn�es sera 
puni d'un emprisonnement de trois mois � trois ans et 
d'une amende de 10.000 F � 100.000 F ou de l'une de ces 
deux peines.</p>

<p><strong>Article 462-4</strong>
<br />
Quiconque aura, intentionnellement et au m�pris des 
droits d'autrui, directement ou indirectement, introduit 
des donn�es dans un syst�me de traitement automatique ou 
supprim� ou modifi� les donn�es qu'il contient ou leurs 
modes de traitement ou de transmission, sera puni d'un emprisonnement de trois 
mois � trois ans et d'une amende de 2.000 F � 500.000 F 
ou de l'une de ces deux peines.</p>

<p><strong>Article 462-5</strong>
<br />
Quiconque aura proc�d� � la falsification de documents 
informatis�s, quelle que soit leur forme, de nature � 
causer un pr�judice � autrui, sera puni d'un 
emprisonnement d'un an � cinq ans et d'un amende de 
20.000 F � 200.000 F.</p>

<p><strong>Article 462-6</strong>
<br />
Quiconque aura sciemment fait usage des documents 
informatis�s vis�s � l'article 462-5 sera puni d'un 
emprisonnement d'un an � cinq ans et d'une amende de 
20.000 F � 2.000.000 F ou de l'une de ces deux 
peines.</p>

<p><strong>Article 462-7</strong>
<br />
La tentative des d�lits pr�vus par les articles 462-2 � 
462-6 est punie des m�mes peines que le d�lit lui-m�me.</p>

<p><strong>Article 462-8</strong>
<br />
Quiconque aura particip� � une association form�e ou � 
une entente �tablie en vue de la pr�paration, 
concr�tis�e par un ou plusieurs faits mat�riels, d'une 
ou de plusieurs infractions pr�vues par les articles 
462-2 � 462-6 sera puni des peines pr�vues pour 
l'infraction elle-m�me ou pour l'infraction la plus 
s�v�rement r�prim�e.</p>

<p><strong>Article 462-9</strong>
<br />
Le tribunal pourra prononcer la confiscation des mat�riels 
appartenant au condamn� et ayant servi � commettre les 
infractions pr�vues au pr�sent chapitre.</p>

<?php
require("./footer.php");
?>